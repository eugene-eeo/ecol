#ifndef VIZING_H
#define VIZING_H

#include "graph.h"

int vizing_heuristic(graph* g, int* P, int delta);

#endif /* VIZING_H */
